/* 
 * File:   main.c
 * Author: ar424045
 *
 * Created on 14 d�cembre 2023, 09:10
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    
    return (EXIT_SUCCESS);
}

